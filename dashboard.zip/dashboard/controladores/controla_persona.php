<?php
$cantidad = $_POST["cantidad"];
$vaor = $cantidad * 2500;
if($cantidad <=0)
{
echo "ojo valor invalido ";

}else
{
    echo "Total a pagar: ".$vaor;
}


?>