<?php
$valor = $_POST["cantidad"];
$describir = $_POST["describir"];
if($valor <=0  or $valor >100000)
{
echo "ojo valor invalido ";

}else
{
    echo "Total a pagar: ".$valor;
    echo "<br>Descripcion de la compra: ".$describir;
}


?>