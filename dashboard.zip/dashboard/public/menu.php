<ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="index.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                vender
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="video.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                Comprar
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="suscripciones.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                auacripciones
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="historial.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                Historial
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="#">
                <svg class="bi"><use xlink:href="#graph-up"/></svg>
                Shorts
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="#">
                <svg class="bi"><use xlink:href="#puzzle"/></svg>
                Tú
              </a>
            </li>
          </ul>