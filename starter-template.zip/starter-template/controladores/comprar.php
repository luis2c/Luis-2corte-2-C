<?php
$valor = $_POST["edad"];
if($valor <18 )
{
echo "Es menor de edad no se puede registrar ";

}else
{
    echo "Resgistro completado ";
    
}


?>