<?php

$v = $_POST["opciones"];
$c = $_POST["cantidad"];
$b = $_POST["precio"];
if($c>0 or $b>0)
{
echo "La prenda escogida fue: " .$v;
echo "<br>Llegaron: ".$c;
echo "<br>Usted pago: ".$b;
}else
{
echo "OJO VALOR INVALIDO";
}


?>