<?php

$c = $_POST["cant"];
$b = $_POST["pro"];
if($c>0)
{
echo "usted escogio: ".$c; 
echo " ".$b;
}else
{
echo "OJO VALOR INVALIDO";
}


?>