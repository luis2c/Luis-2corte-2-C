<ul class="right hide-on-med-and-down" >
         <li><a href="index.php">inicio</a></li>
        <li><a href="vender.php">Vender</a></li>
        <li><a href="comprar.php">Comprar</a></li>
        <li><a href="registrar.php">Registrar Cliente</a></li>
      </ul>